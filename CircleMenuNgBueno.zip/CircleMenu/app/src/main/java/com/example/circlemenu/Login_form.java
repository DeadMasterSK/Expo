package com.example.circlemenu;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.circlemenu.entidades.Docente;
import com.example.circlemenu.utilidades.Utilidades;
import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class Login_form extends AppCompatActivity {
    EscanearQRActivity qr=new EscanearQRActivity();
    private ZXingScannerView vistaescanerDocente;
    EditText usr,pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getSupportActionBar().setTitle("Login");
        ConexionSQLiteHelper conn=new ConexionSQLiteHelper(this,"db docentes",null,1);
        SQLiteDatabase db = conn.getWritableDatabase();
        db.execSQL("INSERT INTO docentes VALUES ('docente1','usuario','admin1234')");
        usr=(EditText) findViewById(R.id.editText4);
        pwd=(EditText) findViewById(R.id.editText5);
    }
    public void btn_regis(View view){
        startActivity(new Intent(getApplicationContext(),Signup_Form.class));
    }

    public void escanearDocente(View v){
        vistaescanerDocente = new ZXingScannerView(this);
        vistaescanerDocente.setResultHandler(new zxingscanner());
        setContentView(vistaescanerDocente);
        vistaescanerDocente.startCamera();
    }
    class zxingscanner implements ZXingScannerView.ResultHandler {

        @Override
        public void handleResult(Result result) {
            String infoDocente= result.getText();
            setContentView(R.layout.activity_login_form);
            vistaescanerDocente.stopCamera();
            //String rAlumno = codigo.getText().toString();
            //String[] sAlumno = rAlumno.split("(?=\\s)");
            String[] sDocente=infoDocente.split("(?=\\s)");
            Docente docente=new Docente(sDocente[0].toString().trim(),sDocente[1].toString().trim(),sDocente[2].toString().trim());
            usr=(EditText) findViewById(R.id.editText4);
            pwd=(EditText) findViewById(R.id.editText5);
            usr.setText(docente.getUsuario());
            pwd.setText(docente.getPassword());

        }
    }
    public void IniciarSecion(View v) {
        String usuario = usr.getText().toString();
        String password = pwd.getText().toString();
        try {
            if (usr.getText().toString().equals("") && pwd.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Campo vacio, es necesario escanear o ingresar ", Toast.LENGTH_SHORT).show();
            } else {

                ConexionSQLiteHelper conn = new ConexionSQLiteHelper(this, "db docentes", null, 1);
                try {
                    SQLiteDatabase db = conn.getReadableDatabase();

                    Cursor cursor = db.rawQuery("SELECT usuario,password FROM " + Utilidades.TABLA_DOCENTE + " WHERE usuario='" + usuario.trim() + "' and password='" + password + "'", null);
                    if (cursor.moveToNext()) {
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    } else {
                        AlertDialog alertDialog = new AlertDialog.Builder(Login_form.this).create();
                        alertDialog.setTitle("Docente");
                        alertDialog.setMessage("No existe su usuario. ");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "No se puede ingresar." + e, Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "No se puede enlazar a la  BBDD " + e, Toast.LENGTH_LONG).show();
        }
    }
}
