package com.example.circlemenu.entidades;

public class Alumno {
    private String nombre;
    private String apellido;
    private String seccion;

    public Alumno() {
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    public Alumno(String nombre, String apellido, String seccion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.seccion = seccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

}
