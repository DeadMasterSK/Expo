package com.example.circlemenu;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.hitomi.cmlibrary.CircleMenu;
import com.hitomi.cmlibrary.OnMenuSelectedListener;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CircleMenu circleMenu= findViewById(R.id.circle_menu);
        final String [] menus = {
                "Gestionar",
                "Mostrar",
                "Control de asistencia"
        };
    circleMenu.setMainMenu(Color.parseColor("#CDCDCD"),R.drawable.ic_add,R.drawable.ic_clea)
            .addSubMenu(Color.parseColor("#CD0000"),R.drawable.ic_lupa)//una lupa
            .addSubMenu(Color.parseColor("#00CD00"),R.drawable.ic_lista)// una lista (Simple)
            .addSubMenu(Color.parseColor("#0000CD"),R.drawable.ic_cheke)//una lista pero que tenga un chequesito
            //.addSubMenu(Color.parseColor("#CDCD00"),R.drawable.ic_mostrar)
            .setOnMenuSelectedListener(new OnMenuSelectedListener() {
                @Override
                public void onMenuSelected(int i) {
                    //Toast.makeText(MainActivity.this,"You Click"+ menus[i],Toast.LENGTH_LONG).show();
                    if (menus[i].equals(menus[0])){
                        Intent e = new Intent(MainActivity.this, GestionAsistenciaActivity.class);
                        startActivity(e);
                    }
                    else if (menus[i].equals(menus[1])) {
                        Intent e = new Intent(MainActivity.this, MostrarAsistencia.class);
                        startActivity(e);
                    }
                    else if (menus[i].equals(menus[2])) {
                        Intent e = new Intent(MainActivity.this, EscanearQRActivity.class);
                        startActivity(e);                    }

                }
            });

    }
}
