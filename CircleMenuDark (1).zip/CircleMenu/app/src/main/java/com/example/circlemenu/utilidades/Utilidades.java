package com.example.circlemenu.utilidades;

public class Utilidades {
    //Constantes campos tabla alumnos
    public static final String TABLA_ALUMNO="alumnos";
    public static final String CAMPO_NOMBRE="nombre";
    public static final String CAMPO_APELLIDO="apellido";
    public static final String CAMPO_SECCION="seccion";
    public static final String CREAR_TABLA_ALUMNO="CREATE TABLE "+TABLA_ALUMNO+
            " ("+CAMPO_NOMBRE+" TEXT, "+CAMPO_APELLIDO+" TEXT, "+CAMPO_SECCION+" TEXT)";

    /*Campos de la tabla docente*/
    public static final String TABLA_DOCENTE="docentes";
    public static final String CAMPO_NOMBRE_DOCENTE="nombre";
    public static final String CAMPO_USUARIO_DOCENTE="usuario";
    public static final String CAMPO_PASSWORD_DOCENTE="password";
    public static final String CREAR_TABLA_DOCENTE="CREATE TABLE "+TABLA_DOCENTE+
            " ("+CAMPO_NOMBRE_DOCENTE+" TEXT, "+CAMPO_USUARIO_DOCENTE+" TEXT, "+CAMPO_PASSWORD_DOCENTE+" TEXT)";

}
