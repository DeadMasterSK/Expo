package com.example.controlasistencia;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.controlasistencia.utilidades.Utilidades;

public class GestionAsistenciaActivity extends AppCompatActivity {
    EditText nombre,apellido,seccion;
    ConexionSQLiteHelper conn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_asistencia);
        nombre=(EditText) findViewById(R.id.editText);
        apellido=(EditText) findViewById(R.id.editText2);
        seccion=(EditText) findViewById(R.id.editText3);
        conn=new ConexionSQLiteHelper(getApplicationContext(),"db alumnos",null,1);


    }
    public void consultar(View v){
        SQLiteDatabase db=conn.getWritableDatabase();
        String[] parametro={nombre.getText().toString()};
        String[] campos={Utilidades.CAMPO_APELLIDO,Utilidades.CAMPO_SECCION};
        try{
            Cursor cursor=db.query(Utilidades.TABLA_ALUMNO,campos,Utilidades.CAMPO_NOMBRE+"=?",parametro,null,null,null);
            cursor.moveToFirst();
            apellido.setText(cursor.getString(0));
            seccion.setText(cursor.getString(1));
            cursor.close();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"El alumno no existe.",Toast.LENGTH_SHORT).show();
            limpiar();
        }
    }

    private void limpiar() {
        nombre.setText("");
        apellido.setText("");
        seccion.setText("");
    }
    public void actualizar(View v){
        SQLiteDatabase db=conn.getWritableDatabase();
        String[] parametro={nombre.getText().toString()};
        ContentValues values=new ContentValues();
        values.put(Utilidades.CAMPO_APELLIDO,apellido.getText().toString());
        values.put(Utilidades.CAMPO_SECCION,seccion.getText().toString());
        try{
            db.update(Utilidades.TABLA_ALUMNO,values,Utilidades.CAMPO_NOMBRE+"=?",parametro);
            Toast.makeText(getApplicationContext(),"Se actualizo el alumno",Toast.LENGTH_SHORT).show();
            db.close();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"No se pudo actualizar el alumno",Toast.LENGTH_LONG).show();
            limpiar();
        }
    }
    public void eliminar(View v){
        SQLiteDatabase db=conn.getWritableDatabase();
        String[] parametro={nombre.getText().toString()};
        try{
            db.delete(Utilidades.TABLA_ALUMNO,Utilidades.CAMPO_NOMBRE+"=?",parametro);
            Toast.makeText(getApplicationContext(),"Se elimino el alumno",Toast.LENGTH_SHORT).show();
            limpiar();
            db.close();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"No se pudo eliminar el alumno",Toast.LENGTH_LONG).show();
            limpiar();
        }

    }
}
