package com.example.controlasistencia;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.example.controlasistencia.entidades.Alumno;
import com.example.controlasistencia.utilidades.Utilidades;

import java.util.ArrayList;

public class MostrarAsistencia extends AppCompatActivity {
    ListView mostrarLista;
    ConexionSQLiteHelper Conexion;
    ArrayList<String> listaInformacion;
    ArrayList<Alumno> listaAlumnos;
    Spinner Seccion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_asistencia);
        Seccion = (Spinner) findViewById(R.id.Secciones);

        mostrarLista=(ListView)findViewById(R.id.Lista);

        Conexion = new ConexionSQLiteHelper(getApplicationContext(),"db alumnos",null,1);

       consultarListaAlumnos();
        ArrayAdapter adaptador = new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,listaInformacion);
        mostrarLista.setAdapter(adaptador);
        /*AlertDialog.Builder alerta=new AlertDialog.Builder(ListaAlertMain.this);
        alerta.setMessage("Vista alumnos tabla").show();

        alerta.setTitle("Secciones");
        alerta.setIcon(R.drawable.ic_launcher);

        final ArrayAdapter arrayAdapter= new ArrayAdapter(ListaAlerMain.this)*/

        //Creamos un nuevo AlertDialog.Builder pasandole como parametro el contexto
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);

        alerta.setIcon(R.drawable.ic_launcher);//Definimos el icono
        alerta.setTitle("Opciones ");//Asignamos un titulo al mensaje

        //Creamos un nuevo ArrayAdapter de 'Strings' y pasamos como parametros (Contexto, int id "Referencia a layout");
        final ArrayAdapter arrayAdapter = new ArrayAdapter(this,android.R.layout.select_dialog_singlechoice);

        //Añadimos los elementos a mostrar
        arrayAdapter.add("2G1");
        arrayAdapter.add("2G2");
        arrayAdapter.add("2G3");
        arrayAdapter.add("2G4");
        arrayAdapter.add("2G5");

        //Creamos un boton para cancelar el dialog
        alerta.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();//Cerramos el dialogo
            }
        });

        //Capturamos el evento 'OnClick' de los elementos en el dialogo
        alerta.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int _item) {

                //Creamos un toast para mostrar el elemento selecionado
                Toast.makeText(getApplicationContext(), arrayAdapter.getItem(_item).toString(), Toast.LENGTH_SHORT).show();
                switch (arrayAdapter.getItem(_item).toString()){
                    case "2G2":
                        startActivity(new Intent(getApplicationContext(),Seccion2G2.class));
                        break;

                    case "2G3":
                        startActivity(new Intent(getApplicationContext(),Seccion2G3.class));
                        break;

                    case "2G4":
                        startActivity(new Intent(getApplicationContext(),Seccion2G4.class));
                        break;

                    case "2G5":
                        startActivity(new Intent(getApplicationContext(),Seccion2G5.class));
                        break;
                }

            }
        });
        alerta.show();
    }


    public void consultarListaAlumnos() {

        SQLiteDatabase db=Conexion.getReadableDatabase();
        String seccion=Seccion.getSelectedItem().toString();
        Alumno alumno = null;
        String aula = "2G1";
        listaAlumnos=new ArrayList<Alumno>();
        Cursor cursor = db.rawQuery("SELECT * FROM alumnos WHERE seccion= '"+aula+"'",null);
        while (cursor.moveToNext()){
            alumno=new Alumno();
            alumno.setNombre(cursor.getString(0));
            alumno.setApellido(cursor.getString(1));
            alumno.setSeccion(cursor.getString(2));
            listaAlumnos.add(alumno);
        }
        ObtenerLista();
    }

    private void ObtenerLista() {
        listaInformacion = new ArrayList<String>();

        for (int i = 0; i<listaAlumnos.size(); i++){
            listaInformacion.add(listaAlumnos.get(i).getNombre()+" - "+listaAlumnos.get(i).getApellido()+" - "+listaAlumnos.get(i).getSeccion());
        }
    }

}
