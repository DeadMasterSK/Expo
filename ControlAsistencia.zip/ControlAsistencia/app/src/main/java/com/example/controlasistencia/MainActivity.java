package com.example.controlasistencia;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends ListActivity {
    String[] menu={"Control de Asistencia","Gestionar Asistencia","Mostrar Asistencia"};
    String [] activities={"EscanearQRActivity","GestionAsistenciaActivity",
            "MostrarAsistencia"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setListAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_expandable_list_item_1,menu));
        ConexionSQLiteHelper conn=new ConexionSQLiteHelper(this,"db alumnos",null,1);

    }
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id){
        super.onListItemClick(l,v,position,id);

            String nombreValue=activities[position];
            try {
                Class<?> clase=Class.forName("com.example.controlasistencia."+nombreValue);
                Intent inte=new Intent(this,clase);
                this.startActivity(inte);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                Toast toast=Toast.makeText(this,"No se encuentra el activities"+e,Toast.LENGTH_SHORT);
            }


    }
}
