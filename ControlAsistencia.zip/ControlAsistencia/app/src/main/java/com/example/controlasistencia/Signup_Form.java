package com.example.controlasistencia;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Signup_Form extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup__form);
        getSupportActionBar().setTitle("Registrarse");
    }
}
